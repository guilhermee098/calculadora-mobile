package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

    EditText txt1, txt2;
    Button btnSoma, btnSubtrai, btnDivide, btnMultiplica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt1 = (EditText) findViewById(R.id.txt1);
        txt2 = (EditText) findViewById((R.id.txt2));
        btnSoma = (Button) findViewById(R.id.btnSoma);
        btnSubtrai = (Button) findViewById(R.id.btnSubtrai);
        btnDivide = (Button) findViewById(R.id.btnDivide);
        btnMultiplica = (Button) findViewById(R.id.btnMultiplica);


        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(
                        txt1.getText().toString());
                double num2 = Double.parseDouble(
                        txt2.getText().toString());
                double soma = num1 + num2;

                AlertDialog.Builder dialogo = new
                AlertDialog.Builder(MainActivity.this);

                dialogo.setTitle("Resultado da soma");
                dialogo.setMessage("O resultado da soma é " + soma);
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();


            }
        });
        btnSubtrai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(
                        txt1.getText().toString());
                double num2 = Double.parseDouble(
                        txt2.getText().toString());
                double sub = num1 - num2;

                AlertDialog.Builder dialogo = new
                        AlertDialog.Builder(MainActivity.this);

                dialogo.setTitle("Resultado da soma");
                dialogo.setMessage("O resultado da sub é " + sub);
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();


            }
        });
        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(
                        txt1.getText().toString());
                double num2 = Double.parseDouble(
                        txt2.getText().toString());
                double divi = num1 / num2;

                AlertDialog.Builder dialogo = new
                        AlertDialog.Builder(MainActivity.this);

                dialogo.setTitle("Resultado da soma");
                dialogo.setMessage("O resultado da divisão é " + divi);
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();


            }
        });
        btnMultiplica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(
                        txt1.getText().toString());
                double num2 = Double.parseDouble(
                        txt2.getText().toString());
                double mult = num1 * num2;

                AlertDialog.Builder dialogo = new
                        AlertDialog.Builder(MainActivity.this);

                dialogo.setTitle("Resultado da soma");
                dialogo.setMessage("O resultado da multiplicação é " + mult);
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();


            }
        });
    }


}